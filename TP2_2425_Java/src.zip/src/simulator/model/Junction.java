package simulator.model;

import java.util.*;

public class Junction {

    // Listas y mapas internos
    private List<Road> _inRoads;
    private List<List<Vehicle>> _queues;
    private Map<Road, List<Vehicle>> _queueByRoad;
    private Map<Junction, Road> _outRoadByJunction;
    private int _greenLightIndex;
    private int _lastSwitchingTime;
    private LightSwitchingStrategy _lss;
    private DequeuingStrategy _dqs;

    // Constructor
    public Junction() {
        _inRoads = new ArrayList<>();
        _queues = new ArrayList<>();
        _queueByRoad = new HashMap<>();
        _outRoadByJunction = new HashMap<>();
        _greenLightIndex = -1;
        _lastSwitchingTime = 0;
    }

    // Añadir una carretera entrante
    public void addIncomingRoad(Road r) {
        if (r.getDestJunc() != this) {
            throw new IllegalArgumentException("Road destination must be this junction.");
        }
        _inRoads.add(r);
        _queues.add(new ArrayList<>());  // Creamos una nueva cola vacía para esta carretera
        _queueByRoad.put(r, new ArrayList<>());
    }

    // Añadir una carretera saliente
    public void addOutgoingRoad(Road r) {
        _outRoadByJunction.put(this, r);  // Añadimos la carretera saliente al mapa
    }

    // Añadir un vehículo a la cola correspondiente
    public void enter(Vehicle v) {
        Road r = v.getCurrentRoad();
        List<Vehicle> queue = _queueByRoad.get(r);
        queue.add(v);  // Añadimos el vehículo a la cola correspondiente a la carretera
    }

    // Obtener la carretera hacia el siguiente cruce
    public Road roadTo(Junction j) {
        return _outRoadByJunction.get(j);  // Devolvemos la carretera asociada con el siguiente cruce
    }

    // Avanzar el estado del cruce
    public void advance(int time) {
        // Si hay una carretera con semáforo verde
        if (_greenLightIndex != -1) {
            List<Vehicle> queue = _queues.get(_greenLightIndex);
            List<Vehicle> vehiclesToAdvance = _dqs.dequeue(queue);  // Obtenemos los vehículos a avanzar

            for (Vehicle v : vehiclesToAdvance) {
                v.moveToNextRoad();  // Mover el vehículo al siguiente camino
                queue.remove(v);  // Eliminar el vehículo de la cola
            }
        }

        // Elegir la siguiente carretera que tendrá el semáforo verde
        _lss.chooseNextGreen(_inRoads, _queueByRoad, time);
    }

    // Getters y setters
    public List<Road> getInRoads() {
        return _inRoads;
    }

    public List<List<Vehicle>> getQueues() {
        return _queues;
    }

    public Map<Road, List<Vehicle>> getQueueByRoad() {
        return _queueByRoad;
    }

    public int getGreenLightIndex() {
        return _greenLightIndex;
    }

    public void setGreenLightIndex(int index) {
        _greenLightIndex = index;
    }

    public int getLastSwitchingTime() {
        return _lastSwitchingTime;
    }

    public void setLastSwitchingTime(int lastSwitchingTime) {
        _lastSwitchingTime = lastSwitchingTime;
    }

    public LightSwitchingStrategy getLss() {
        return _lss;
    }

    public void setLss(LightSwitchingStrategy lss) {
        _lss = lss;
    }

    public DequeuingStrategy getDqs() {
        return _dqs;
    }

    public void setDqs(DequeuingStrategy dqs) {
        _dqs = dqs;
    }
}
