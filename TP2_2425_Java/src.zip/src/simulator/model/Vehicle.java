package simulator.model;

import java.util.List;

public class Vehicle {
    private String _id;
    private int _maxSpeed;
    private int _contClass;
    private List<Junction> _itinerary;
    private int _location;
    private int _speed;
    private VehicleStatus _status;
    private int _itineraryIndex;
    private Road _currentRoad;
    private double _totalContamination;

    public Vehicle(String id, int maxSpeed, int contClass, List<Junction> itinerary) {
        if (itinerary == null || itinerary.size() < 2) {
            throw new IllegalArgumentException("Itinerary must have at least two junctions.");
        }
        _id = id;
        _maxSpeed = maxSpeed;
        _contClass = contClass;
        _itinerary = itinerary;
        _location = 0;
        _speed = 0;
        _status = VehicleStatus.PENDING;
        _itineraryIndex = 0;
        _totalContamination = 0;
    }

    public void advance(int time) {
        if (_status != VehicleStatus.TRAVELING) {
            return; // Do nothing if the vehicle is not traveling
        }

        // Update location based on speed
        _location += _speed;
        if (_location > _currentRoad.getLength()) {
            _location = _currentRoad.getLength();
        }

        // Calculate contamination (distance * contamination class)
        double distanceTravelled = _location - (_location - _speed);
        double contamination = distanceTravelled * _contClass;
        _totalContamination += contamination;
        _currentRoad.addContamination(contamination);

        // If the vehicle reached the end of the road
        if (_location == _currentRoad.getLength()) {
            Junction nextJunction = _currentRoad.getDest();
            nextJunction.enter(this);  // Enter the junction
            _status = VehicleStatus.WAITING;  // Waiting in the junction
        }
    }

    public void moveToNextRoad() {
        if (_status != VehicleStatus.PENDING && _status != VehicleStatus.WAITING) {
            throw new IllegalStateException("Vehicle must be PENDING or WAITING to move.");
        }

        if (_currentRoad != null) {
            _currentRoad.exit(this);  // Exit the current road
        }

        if (_itineraryIndex == _itinerary.size()) {
            _status = VehicleStatus.ARRIVED;  // Vehicle has arrived at its destination
            _currentRoad = null;
            _speed = 0;
        } else {
            Junction currentJunction = _itinerary.get(_itineraryIndex);
            Road nextRoad = currentJunction.getNextRoad();
            enterRoad(nextRoad);  // Enter the next road
            _status = VehicleStatus.TRAVELING;
            _location = 0;  // Start at the beginning of the road
        }
    }

    private void enterRoad(Road road) {
        _currentRoad = road;
        _speed = _maxSpeed;
        _itineraryIndex++;
    }

    // Getters and setters
    public String getId() {
        return _id;
    }

    public int getMaxSpeed() {
        return _maxSpeed;
    }

    public int getContClass() {
        return _contClass;
    }

    public List<Junction> getItinerary() {
        return _itinerary;
    }

    public VehicleStatus getStatus() {
        return _status;
    }

    public double getTotalContamination() {
        return _totalContamination;
    }

    public Road getCurrentRoad() {
        return _currentRoad;
    }

    public int getLocation() {
        return _location;
    }

    public void setStatus(VehicleStatus status) {
        this._status = status;
    }

    public void setLocation(int location) {
        this._location = location;
    }
}
