package simulator.model;

public class InterCityRoad extends Road {

    // Constructor de la carretera InterCityRoad
    public InterCityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
        // Llamamos al constructor de la clase base Road
        super(id, srcJunc, destJunc, maxSpeed, contLimit, length, weather);
    }

    // Reduce la contaminación total de la carretera según el clima
    @Override
    public void reduceTotalContamination() {
        // Dependiendo del clima, la contaminación se reduce en un porcentaje diferente
        int reductionPercentage = switch (weather) {
            case SUNNY -> 2;
            case CLOUDY -> 3;
            case RAINY -> 10;
            case WINDY -> 15;
            case STORM -> 20;
        };

        totalCO2 = ((100 - reductionPercentage) * totalCO2) / 100;  // Reducimos la contaminación total
    }

    // Actualiza el límite de velocidad de la carretera
    @Override
    public void updateSpeedLimit() {
        // Si la contaminación total excede el límite, reducimos la velocidad a la mitad
        if (totalCO2 > contLimit) {
            speedLimit = maxSpeed / 2;
        } else {
            speedLimit = maxSpeed;  // De lo contrario, mantenemos la velocidad máxima
        }
    }

    // Calcula la velocidad de un vehículo en la carretera dependiendo del clima
    @Override
    public int calculateVehicleSpeed(Vehicle v) {
        int speed = speedLimit;

        // Si el clima es tormentoso, reducimos la velocidad del vehículo en un 20%
        if (weather == Weather.STORM) {
            speed = (speed * 8) / 10;
        }

        return speed;
    }
}
