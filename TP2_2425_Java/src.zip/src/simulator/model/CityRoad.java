package simulator.model;

public class CityRoad extends Road {

    // Constructor de la carretera CityRoad
    public CityRoad(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
        // Llamamos al constructor de la clase base Road
        super(id, srcJunc, destJunc, maxSpeed, contLimit, length, weather);
    }

    // Reduce la contaminación total de la carretera según el clima
    @Override
	
    public void reduceTotalContamination() {
        int reduction = (weather == Weather.WINDY || weather == Weather.STORM) ? 10 : 2; // Reducción de contaminación
        totalCO2 = Math.max(0, totalCO2 - reduction); // Aseguramos que no haya contaminación negativa
    }

    // Actualiza el límite de velocidad de la carretera
    @Override
    public void updateSpeedLimit() {
        speedLimit = maxSpeed; // En este caso, el límite de velocidad es igual al máximo permitido
    }

    // Calcula la velocidad de un vehículo en la carretera dependiendo de su clase de contaminación
    @Override
    public int calculateVehicleSpeed(Vehicle v) {
        // La velocidad depende de la clase de contaminación del vehículo
        return ((11 - v.getContClass()) * speedLimit) / 11; // Calcula la velocidad en base a la clase de contaminación
    }
}
