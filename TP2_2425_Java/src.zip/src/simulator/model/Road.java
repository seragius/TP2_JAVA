package simulator.model;

import java.util.ArrayList;
import java.util.List;

public abstract class Road {

    protected String id;
    protected Junction srcJunc;
    protected Junction destJunc;
    protected int maxSpeed;
    protected int contLimit;
    protected int length;
    protected Weather weather;
    protected int speedLimit;
    protected int totalCO2;
    protected List<Vehicle> vehicles;

    // Constructor
    public Road(String id, Junction srcJunc, Junction destJunc, int maxSpeed, int contLimit, int length, Weather weather) {
        this.id = id;
        this.srcJunc = srcJunc;
        this.destJunc = destJunc;
        this.maxSpeed = maxSpeed;
        this.contLimit = contLimit;
        this.length = length;
        this.weather = weather;
        this.vehicles = new ArrayList<>();
        srcJunc.addOutgoingRoad(this);
        destJunc.addIncomingRoad(this);
    }

    // Métodos abstractos a ser implementados en subclases
    public abstract void updateSpeedLimit();
    public abstract void reduceTotalContamination();
    public abstract int calculateVehicleSpeed(Vehicle v);

    // Método para agregar un vehículo a la carretera
    public void enter(Vehicle v) {
        // Verifica si el vehículo tiene la ubicación en 0 y velocidad 0 antes de ingresar
        if (v.getLocation() != 0 || v.getSpeed() != 0) {
            throw new IllegalArgumentException("Vehicle must be at the beginning of the road with speed 0 to enter");
        }
        vehicles.add(v);
    }

    // Método para retirar un vehículo de la carretera
    public void exit(Vehicle v) {
        vehicles.remove(v);
    }

    // Avanza el estado de la carretera y sus vehículos
    public void advance(int time) {
        reduceTotalContamination();
        updateSpeedLimit();

        // Actualiza la velocidad de los vehículos
        for (Vehicle v : vehicles) {
            v.advance(time);  // Esto avanzará la ubicación del vehículo
        }

        // Ordena los vehículos por su ubicación (de mayor a menor)
        vehicles.sort((v1, v2) -> Integer.compare(v2.getLocation(), v1.getLocation()));
    }

    // Getters y setters
    public String getId() {
        return id;
    }

    public Junction getSrcJunc() {
        return srcJunc;
    }

    public Junction getDestJunc() {
        return destJunc;
    }

    public int getMaxSpeed() {
        return maxSpeed;
    }

    public int getContLimit() {
        return contLimit;
    }

    public int getLength() {
        return length;
    }

    public Weather getWeather() {
        return weather;
    }

    public int getSpeedLimit() {
        return speedLimit;
    }

    public int getTotalCO2() {
        return totalCO2;
    }

    public List<Vehicle> getVehicles() {
        return vehicles;
    }
}
